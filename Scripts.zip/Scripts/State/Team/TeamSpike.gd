extends "res://Scripts/State/Team/TeamState.gd"
class_name TeamSpike

var rng = RandomNumberGenerator.new()
var hit = false
var timeStart = 0
var timeEnd = 0

func Enter(_team:TeamNode):
	nameOfState = "Spike"
	rng.randomize()
	hit = false
	pass
func Update(team:TeamNode):
	if !team.chosenSpiker:
		return

	team.UpdateTimeTillDigTarget()
#	Console.AddNewLine(str((team.ball.position - team.chosenSpiker.setRequest.target).length()))
	if !hit &&team.ball.inPlay && team.ball.linear_velocity.y <= 0 && team.ball.position.y <= team.chosenSpiker.stats.spikeHeight && team.ball.position.distance_to(team.chosenSpiker.setRequest.target) <= 1:
		Console.AddNewLine(str(team.ball.position))
		team.ball.position = team.chosenSpiker.setRequest.target # lol, hacky but might make the predictions work
		SpikeBall(team)
		timeEnd = Time.get_unix_time_from_system()
		var timeElapsed = timeEnd - timeStart
		Console.AddNewLine("Actual time when ball ready to be spiked: " + str(timeElapsed), Color.GOLD)
#		if team.ball.linear_velocity.z > 0:
#			if team.ball.position.z > team.chosenSpiker.setRequest.target.z: #&& \
#				if(team.ball.position - team.chosenSpiker.setRequest.target).length() < 0.5:# &&\
#		if abs(team.ball.position.y - (team.chosenSpiker.position.y + team.chosenSpiker.stats.height * 1.33)) < 0.5:
#			if Maths.XZVector(team.ball.position - team.chosenSpiker.position).length() < 2:
#			if Vector3(team.chosenSpiker.position.x, team.chosenSpiker.position.y + team.chosenSpiker.stats.height * 1.33, team.chosenSpiker.position.z).distance_to(team.ball.position) <= 1:
#				team.chosenSpiker.spikeState.AdjustSpike(team.defendState.otherTeam)

#		elif team.ball.linear_velocity.z < 0:
#			if team.ball.position.z < team.chosenSpiker.setRequest.target.z:# &&\

##				if (team.ball.position - team.chosenSpiker.setRequest.target).length() < 0.5:# &&\
#				if Maths.XZVector(team.ball.position - team.chosenSpiker.position).length() < 0.5:
#					SpikeBall(team)
#		else:
#			Console.AddNewLine("No ball z vel...")
#			if team.ball.position.x <= team.setTarget.target.x &&\
#			(team.ball.position - team.chosenSpiker.setRequest.target).length() < 0.5:
#				SpikeBall(team)

func Exit(_team:TeamNode):
	pass

func SpikeBall(team:TeamNode):
	Console.AddNewLine(str("%.3f" % team.chosenSpiker.setRequest.target.distance_to(team.ball.position)) + " distance from predicted contact point to actual", Color.DEEP_PINK)

	var netHeightPlusBallClearance:float = 2.43 + .13
	var ball:Ball = team.ball

	if team.setTarget.height > netHeightPlusBallClearance:
		#Draw a line from the ball to the target. If the point where it crosses the
		#net is higher than said net, it can be hit, otherwise roll
		var netPass:Vector3

		var distanceFactor:float = ball.position.x / (abs(ball.position.x) + abs(ball.attackTarget.x))
		if ball.position.x < 0:
			distanceFactor *= -1;

		netPass = ball.position + (ball.attackTarget - ball.position) * distanceFactor


		var u = 100.0/3.6
		var _topspin = team.chosenSpiker.spikeState.customTopspin
		var _newVel = Maths.FindParabolaForGivenSpeed(ball.position, ball.attackTarget, u, false, _topspin)
		var realNetPass = Maths.FindNetPass(ball.position, ball.attackTarget, _newVel, _topspin)
		Console.AddNewLine("Net Pass: " + str(realNetPass), Color.LIME_GREEN)

		if realNetPass.y > netHeightPlusBallClearance:
			#var xzDistToTarget:float = (Vector3(ball.position.x, 0, ball.position.z) - Vector3(ball.attackTarget.x, 0, ball.attackTarget.z)).length()
			#var y = ball.position.y
			#var g = team.chosenSpiker.g

			#initial velocity of spike in mps

			#print("Spike Speed(m/s): " + str(u))

			ball.difficultyOfReception = u/37.0*team.chosenSpiker.stats.spike*2
			ball.gravity_scale = team.chosenSpiker.spikeState.customTopspin
			ball.topspin = ball.gravity_scale
			var newVel = Maths.FindParabolaForGivenSpeed(ball.position, ball.attackTarget, u, false, ball.topspin)
			if newVel == null:
				Console.AddNewLine("ERROR! Impossible parabola requested for spike")
				newVel = Vector3.ZERO
			ball.linear_velocity = newVel
			#await team.get_tree().process_frame
			#ball.linear_velocity = Maths.FindParabolaForGivenSpeed(ball.position, ball.attackTarget, u, false, 3.0)

		else:

			Console.AddNewLine("Ball will clip net if hit at that speed, finding easy parabola", Color.RED)
			#Console.AddNewLine(str(netPass.y), Color.RED)
			#yet again, somehow necessary

			### This doesn't always go over the net, especially at sharp angles
			ball.linear_velocity = Maths.FindWellBehavedParabola(ball.position, ball.attackTarget,  max(2.8, team.setTarget.height + 0.5))
			#ball.linear_velocity =
			###


			#await team.get_tree().process_frame
			#ball.linear_velocity = Maths.FindWellBehavedParabola(ball.position, ball.attackTarget,  max(2.8, team.setTarget.height + 0.5))
			ball.difficultyOfReception = rng.randf_range(0, team.chosenSpiker.stats.spike/4)
			#team.setTarget = null
			#print(ball.attackTarget)


		ball.blockResolver.netPass = Maths.FindNetPass(ball.position, ball.attackTarget, ball.linear_velocity, _topspin)
		if realNetPass.y < netHeightPlusBallClearance:
			Console.AddNewLine("ERROR: Net pass won't clear net", Color.RED)

		if abs(netPass.z) >= 4.49:
			Console.AddNewLine("Ball will pass outside antennae lad", Color.CRIMSON)
			ball.inPlay = false
			if team.data.isHuman:
				team.mManager.PointToTeamB()
			else:
				team.mManager.PointToTeamA()
	else:
		Console.AddNewLine("set target below net height (taking into account ball clearance): " + str("%.1f"%team.setTarget.height))
		ball.linear_velocity = Maths.FindWellBehavedParabola(ball.position, ball.attackTarget,  max(2.8, team.setTarget.height + 0.5))
		ball.difficultyOfReception = rng.randf_range(0, team.chosenSpiker.stats.spike/4)
		team.setTarget = null

	team.mManager.BallSpiked(team.data.isHuman)
	hit = true

	Console.AddNewLine(team.chosenSpiker.stats.lastName + " cranks the ball at " + str("%.1f" % (ball.linear_velocity.length() * 3.6)) + "km/h")
