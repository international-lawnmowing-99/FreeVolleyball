class_name MatchSimulation

extends RefCounted

signal match_completed(winner: String, final_score: Dictionary)

var team_a:TeamData
var team_b:TeamData

var score: Score

var serving_team: TeamData
var team_a_match_data: TeamMatchData
var team_b_match_data: TeamMatchData
var team_a_initial_side: float = -1.0
var team_a_fifth_set_side: float = 0.0
var rally_number: int = 0
var match_over: bool = false
var rally_replays: Array[Dictionary] = []
var workflow_log: SimulationEventLog
var pending_rally_steps: Array[String] = []
var pending_rally_result: Dictionary = {}
var pending_court_snapshots: Array[Dictionary] = []
var pending_court_snapshot_index: int = -1

var rng: RandomNumberGenerator = RandomNumberGenerator.new()

var rally_engine:RallyEngine

func _init(_team_a:TeamData, _team_b:TeamData, _seed: int = -1, _workflow_log: SimulationEventLog = null) -> void:
	team_a = _team_a
	team_b = _team_b
	workflow_log = _workflow_log

	score = Score.new(team_a, team_b)

	if _seed != -1:
		rng.seed = _seed
	else:
		rng.randomize()

	team_a_match_data = TeamMatchData.new(team_a)
	team_a_match_data.team_slot = "a"
	team_b_match_data = TeamMatchData.new(team_b)
	team_b_match_data.team_slot = "b"
	rally_engine = RallyEngine.new(rng, workflow_log)

	team_a_initial_side = -1.0 if rng.randf() < 0.5 else 1.0
	serving_team = team_a if rng.randf() < 0.5 else team_b


	#team_a.set_starting_rotation(team_a.teamStrategy.choose_starting_rotation())
	#team_b.set_starting_rotation(team_b.teamStrategy.choose_starting_rotation())


func play_match() -> Dictionary:
	while not match_over:
		play_point()

	return {
		"winner": score.get_match_winner().teamName,
		"sets_won": score.sets_won,
		"set_history": score.previous_set_scores,
		"total_rallies": rally_number
	}

func play_point() -> Dictionary:
	if match_over:
		var winner := score.get_match_winner()
		return {
			"type": "match_over",
			"winner": winner,
			"winner_name": winner.teamName
		}

	return _play_rally()

func play_set() -> Dictionary:
	if match_over:
		var winner := score.get_match_winner()
		return {
			"type": "match_over",
			"winner": winner,
			"winner_name": winner.teamName
		}

	var set_index_before: int = score.previous_set_scores.size()
	var rallies_in_set: int = 0
	var last_event: Dictionary = {"type": "point"}

	while not match_over and score.previous_set_scores.size() == set_index_before:
		var point_result = play_point()
		last_event = point_result["score_event"]
		rallies_in_set += 1

	return {
		"type": "set_complete",
		"set_number": set_index_before + 1,
		"rallies_played": rallies_in_set,
		"ending_event": last_event
	}

func step() -> void:
	if not match_over:
		play_point()

func next_rally_step() -> Dictionary:
	if match_over and pending_rally_steps.is_empty():
		var winner := score.get_match_winner()
		return {
			"type": "match_over",
			"message": "Match complete",
			"winner": winner,
			"winner_name": winner.teamName if winner != null else ""
		}

	if pending_rally_steps.is_empty():
		if not _prepare_pending_rally():
			var winner := score.get_match_winner()
			return {
				"type": "match_over",
				"message": "Match complete",
				"winner": winner,
				"winner_name": winner.teamName if winner != null else ""
			}

	var message: String = pending_rally_steps.pop_front()
	var step_complete: bool = pending_rally_steps.is_empty()
	var snapshot: Dictionary = {}
	if not pending_court_snapshots.is_empty():
		pending_court_snapshot_index = mini(pending_court_snapshot_index + 1, pending_court_snapshots.size() - 1)
		snapshot = pending_court_snapshots[pending_court_snapshot_index].duplicate(true)
	var result: Dictionary = {
		"type": "rally_step",
		"message": message,
		"step_complete": step_complete,
		"rally_committed": false,
		"court_snapshot": snapshot
	}

	if step_complete:
		var point_result := _commit_pending_rally()
		result["rally_committed"] = true
		result["point_result"] = point_result

	return result

func _play_rally() -> Dictionary:
	_prepare_pending_rally()
	while not pending_rally_steps.is_empty():
		pending_rally_steps.pop_front()
	return _commit_pending_rally()


func _create_rally_context() -> RallyState:
	var state := RallyState.new()
	state.team_a = team_a
	state.team_b = team_b
	state.set_number = score.previous_set_scores.size() + 1
	state.team_a_points = int(score.points.get(team_a, 0))
	state.team_b_points = int(score.points.get(team_b, 0))
	state.team_a_initial_side = team_a_initial_side
	if state.set_number == 5 and team_a_fifth_set_side == 0.0:
		team_a_fifth_set_side = -1.0 if rng.randf() < 0.5 else 1.0
	state.team_a_fifth_set_side = team_a_fifth_set_side
	var serving_match_data: TeamMatchData = _team_match_data_for(serving_team)
	var receiving_team: TeamData = team_b if serving_team == team_a else team_a
	var receiving_match_data: TeamMatchData = _team_match_data_for(receiving_team)

	state.serving_team = serving_team
	state.receiving_team = receiving_team
	state.serving_team_match_data = serving_match_data
	state.receiving_team_match_data = receiving_match_data
	state.current_team = serving_team

	state.rally_number = rally_number

	state.attacker = serving_team
	state.defender = receiving_team
	state.attacker_match_data = serving_match_data
	state.defender_match_data = receiving_match_data

	state.server = serving_match_data.get_server()
	return state

func get_current_server() -> AthleteStats:
	var serving_match_data: TeamMatchData = _team_match_data_for(serving_team)
	return serving_match_data.get_server()

func _team_match_data_for(team: TeamData) -> TeamMatchData:
	if team == team_a:
		return team_a_match_data
	return team_b_match_data

func _handle_score_event(score_attempt):
	if score_attempt["type"] == "set_over":
		print("[Match] Set won by %s. Sets: %d-%d" % [score_attempt["winner"].teamName, score.sets_won[team_a], score.sets_won[team_b]])
	if score_attempt["type"] == "match_over":
		match_over = true
		print("[Match] Match won by %s" % score_attempt["winner"].teamName)
	return {}

func _prepare_pending_rally() -> bool:
	if match_over:
		return false
	if not pending_rally_steps.is_empty():
		return true

	rally_number += 1
	var rally_ctx := _create_rally_context()
	var start_message := ""
	if workflow_log != null:
		var team_name := serving_team.teamName if serving_team != null else "N/A"
		var athlete_name := "N/A"
		if rally_ctx.server != null:
			athlete_name = "%s %s" % [rally_ctx.server.firstName, rally_ctx.server.lastName]
		start_message = "[Sim][rally] Starting rally simulation. | Team=%s | Player=%s" % [team_name, athlete_name]
		workflow_log.log("rally", "Starting rally simulation.", serving_team, rally_ctx.server)

	var rally_result = rally_engine.Resolve(rally_ctx)
	pending_rally_steps = rally_result.step_messages.duplicate()
	if start_message != "":
		pending_rally_steps.push_front(start_message)
	pending_court_snapshots = _snapshots_for_rally_steps(
		_build_pending_court_snapshots(rally_result),
		pending_rally_steps.size()
	)
	pending_court_snapshot_index = -1
	pending_rally_result = {
		"rally_number": rally_number,
		"previous_serving_team": serving_team,
		"rally_result": rally_result
	}
	return true

func _commit_pending_rally() -> Dictionary:
	if pending_rally_result.is_empty():
		return {
			"type": "point_complete",
			"rally_number": rally_number,
			"point_winner": null,
			"point_winner_name": "",
			"score_event": {"type": "point"}
		}

	var rally_result: RallyState = pending_rally_result["rally_result"]
	var previous_serving_team: TeamData = pending_rally_result["previous_serving_team"]
	var replay_payload: Dictionary = rally_result.build_replay_data()
	rally_replays.append({
		"rally_number": rally_result.rally_number,
		"point_winner_name": rally_result.point_winner.teamName,
		"replay": replay_payload
	})
	if rally_result.point_winner != previous_serving_team:
		_team_match_data_for(rally_result.point_winner).rotate_on_sideout()
	serving_team = rally_result.point_winner

	var score_event: Dictionary = score.award_point(rally_result.point_winner)
	if workflow_log != null:
		workflow_log.log("rally", "Rally completed.", rally_result.point_winner)
	print("[Match] Rally %d winner: %s" % [rally_result.rally_number, rally_result.point_winner.teamName])
	print("[Match] Current score: %s %d - %s %d" % [team_a.teamName, score.points[team_a], team_b.teamName, score.points[team_b]])
	print ("=============================")

	_handle_score_event(score_event)

	var point_result := {
		"type": "point_complete",
		"rally_number": rally_result.rally_number,
		"point_winner": rally_result.point_winner,
		"point_winner_name": rally_result.point_winner.teamName,
		"score_event": score_event,
		"replay": replay_payload
	}
	pending_rally_result = {}
	pending_rally_steps.clear()
	pending_court_snapshots.clear()
	pending_court_snapshot_index = -1
	return point_result

func _build_pending_court_snapshots(rally_result: RallyState) -> Array[Dictionary]:
	var snapshots: Array[Dictionary] = []
	if rally_result == null:
		return snapshots

	var setup_snapshot := {
		"phase": "serve_setup",
		"timestamp": 0.0,
		"teams": []
	}
	if rally_result.serving_team_match_data != null:
		setup_snapshot["teams"].append(
			rally_result.serving_team_match_data.build_phase_context(
				"serve",
				-1.0,
				rally_result.server,
				true,
				rally_result.initial_player_tracking_states,
				0.0
			)
		)
	if rally_result.receiving_team_match_data != null:
		setup_snapshot["teams"].append(
			rally_result.receiving_team_match_data.build_phase_context(
				"receive",
				1.0,
				null,
				false,
				rally_result.initial_player_tracking_states,
				0.0
			)
		)
	var setup_ball_position := {"x": -4.7, "y": 2.6, "z": 0.0}
	if not setup_snapshot["teams"].is_empty():
		for player_data in setup_snapshot["teams"][0].get("players", []):
			var internal_state: Dictionary = player_data.get("internal_state", {})
			if bool(internal_state.get("is_server", false)):
				setup_ball_position = player_data.get("position", {}).duplicate(true)
				setup_ball_position["y"] = 2.6
				break
		setup_snapshot["ball_state"] = {"position": setup_ball_position}
	snapshots.append(setup_snapshot)

	for phase_context in rally_result.phase_context_history:
		snapshots.append({
			"phase": str(phase_context.get("phase", "")),
			"timestamp": float(phase_context.get("timestamp", 0.0)),
			"ball_state": phase_context.get("ball_state", {}).duplicate(true),
			"teams": phase_context.get("teams", []).duplicate(true)
		})

	return snapshots

func _snapshots_for_rally_steps(raw_snapshots: Array[Dictionary], step_count: int) -> Array[Dictionary]:
	if raw_snapshots.is_empty() or step_count <= 0:
		return []
	if step_count == 1:
		return [raw_snapshots[0].duplicate(true)]

	var aligned: Array[Dictionary] = []
	for step_index in range(step_count):
		var raw_index := roundi(float(step_index) * float(raw_snapshots.size() - 1) / float(step_count - 1))
		aligned.append(raw_snapshots[raw_index].duplicate(true))
	return aligned

func create_save_data() -> MatchSaveData:
	var save := MatchSaveData.new()

	save.team_a = team_a
	save.team_b = team_b
	save.score_data = score.serialize()
	save.rally_number = rally_number
	save.serving_team_name = serving_team.teamName
	save.rally_replays = rally_replays.duplicate(true)
	#save.team_a_rotation_index = team_a_state.rotation_index
	#save.team_b_rotation_index = team_b_state.rotation_index

	return save
