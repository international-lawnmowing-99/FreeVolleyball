class_name RallyReplayBuilder
extends RefCounted

const REPLAY_FRAME_STEP: float = 0.12
const DEFAULT_BALL_CONTACT_HEIGHT: float = 2.6

static func build(ctx: RallyState) -> Dictionary:
	var replay: Dictionary = ctx.event_log.serialize_for_replay()
	var keyframes: Array[Dictionary] = _build_keyframes(ctx, replay)
	var frames: Array[Dictionary] = _build_interpolated_frames(keyframes)

	replay["keyframes"] = keyframes
	replay["frames"] = frames
	replay["summary"] = {
		"rally_number": ctx.rally_number,
		"serving_team_name": ctx.serving_team.teamName if ctx.serving_team != null else "",
		"receiving_team_name": ctx.receiving_team.teamName if ctx.receiving_team != null else "",
		"point_winner_name": ctx.point_winner.teamName if ctx.point_winner != null else "",
		"frame_count": frames.size(),
		"keyframe_count": keyframes.size(),
		"touch_count": ctx.touch_count,
		"has_stub_data": true
	}
	return replay

static func _build_keyframes(ctx: RallyState, replay: Dictionary) -> Array[Dictionary]:
	var keyframes: Array[Dictionary] = []
	var serialized_events: Array = replay.get("events", [])
	var ball_touches: Array = replay.get("ball_touches", [])
	var context_snapshots: Array = replay.get("context_snapshots", [])

	keyframes.append(_build_setup_keyframe(ctx))

	var touch_count: int = min(ball_touches.size(), context_snapshots.size())
	for i in range(touch_count):
		var touch: Dictionary = ball_touches[i]
		var context: Dictionary = context_snapshots[i]
		var event: Dictionary = {}
		if i < serialized_events.size():
			event = serialized_events[i]
		keyframes.append(_build_touch_keyframe(i + 1, touch, context, event))

	if keyframes.size() == 1:
		keyframes.append(_build_terminal_stub_keyframe(ctx))

	return keyframes

static func _build_setup_keyframe(ctx: RallyState) -> Dictionary:
	var highlighted_server: AthleteStats = ctx.server
	if highlighted_server == null and ctx.serving_team_match_data != null:
		highlighted_server = ctx.serving_team_match_data.get_server()
	var serving_side: float = -1.0
	var receiving_side: float = 1.0
	var serving_context: Dictionary = {}
	var receiving_context: Dictionary = {}

	if ctx.serving_team_match_data != null:
		serving_context = ctx.serving_team_match_data.build_phase_context("serve", serving_side, highlighted_server, true)
	if ctx.receiving_team_match_data != null:
		receiving_context = ctx.receiving_team_match_data.build_phase_context("serve", receiving_side, highlighted_server, false)

	var ball_position := Vector3(serving_side * 4.9, DEFAULT_BALL_CONTACT_HEIGHT, 0.0)
	if highlighted_server != null and ctx.serving_team_match_data != null:
		ball_position = ctx.serving_team_match_data.get_phase_position_for_player(highlighted_server, "serve", serving_side, highlighted_server, true)
		ball_position.y = DEFAULT_BALL_CONTACT_HEIGHT

	return {
		"frame_index": 0,
		"keyframe_index": 0,
		"timestamp": 0.0,
		"phase": "serve_setup",
		"is_keyframe": true,
		"source": "setup_stub",
		"ball": {
			"position": _vector3_to_dict(ball_position),
			"velocity": _vector3_to_dict(Vector3.ZERO),
			"topspin": 0.0
		},
		"teams": [serving_context, receiving_context],
		"focus": {
			"actor_name": _athlete_name(highlighted_server),
			"action": "serve_setup",
			"result": "pre_contact"
		},
		"stub_flags": [
			"pre_touch_ball_state",
			"pre_touch_player_animation"
		]
	}

static func _build_touch_keyframe(index: int, touch: Dictionary, context: Dictionary, event: Dictionary) -> Dictionary:
	var ball_state: Dictionary = context.get("ball_state", {})
	if ball_state.is_empty():
		ball_state = {
			"position": touch.get("position", _vector3_to_dict(Vector3.ZERO)),
			"velocity": touch.get("velocity", _vector3_to_dict(Vector3.ZERO)),
			"topspin": touch.get("topspin", 0.0)
		}

	return {
		"frame_index": index,
		"keyframe_index": index,
		"timestamp": float(touch.get("timestamp", context.get("timestamp", 0.0))),
		"phase": str(touch.get("phase", context.get("phase", ""))),
		"is_keyframe": true,
		"source": "simulation_touch",
		"ball": ball_state,
		"teams": context.get("teams", []),
		"focus": {
			"actor_name": str(event.get("actor_name", touch.get("actor_name", "Unknown Athlete"))),
			"action": str(event.get("action", touch.get("phase", ""))),
			"result": str(event.get("result", touch.get("result", "")))
		},
		"stub_flags": [
			"player_animation_assignment_stub"
		]
	}

static func _build_terminal_stub_keyframe(ctx: RallyState) -> Dictionary:
	return {
		"frame_index": 1,
		"keyframe_index": 1,
		"timestamp": REPLAY_FRAME_STEP,
		"phase": "terminal_stub",
		"is_keyframe": true,
		"source": "terminal_stub",
		"ball": {
			"position": _vector3_to_dict(ctx.ball_position),
			"velocity": _vector3_to_dict(ctx.ball_velocity),
			"topspin": ctx.ball_topspin
		},
		"teams": [],
		"focus": {
			"actor_name": "",
			"action": "point_end",
			"result": ctx.point_winner.teamName if ctx.point_winner != null else ""
		},
		"stub_flags": [
			"terminal_replay_stub"
		]
	}

static func _build_interpolated_frames(keyframes: Array[Dictionary]) -> Array[Dictionary]:
	var frames: Array[Dictionary] = []
	if keyframes.is_empty():
		return frames

	var first_frame: Dictionary = keyframes[0].duplicate(true)
	first_frame["frame_index"] = 0
	frames.append(first_frame)

	for i in range(1, keyframes.size()):
		var previous_frame: Dictionary = keyframes[i - 1]
		var target_frame: Dictionary = keyframes[i]
		var duration: float = max(float(target_frame.get("timestamp", 0.0)) - float(previous_frame.get("timestamp", 0.0)), REPLAY_FRAME_STEP)
		var steps: int = max(1, int(ceil(duration / REPLAY_FRAME_STEP)))

		for step in range(1, steps + 1):
			var weight: float = float(step) / float(steps)
			var frame: Dictionary = _interpolate_frame(previous_frame, target_frame, weight)
			frame["frame_index"] = frames.size()
			frame["is_keyframe"] = step == steps
			frame["keyframe_index"] = int(target_frame.get("keyframe_index", i)) if step == steps else -1
			frames.append(frame)

	return frames

static func _interpolate_frame(previous_frame: Dictionary, target_frame: Dictionary, weight: float) -> Dictionary:
	var interpolated_ball := {
		"position": _lerp_vector3_dict(
			previous_frame.get("ball", {}).get("position", _vector3_to_dict(Vector3.ZERO)),
			target_frame.get("ball", {}).get("position", _vector3_to_dict(Vector3.ZERO)),
			weight
		),
		"velocity": _lerp_vector3_dict(
			previous_frame.get("ball", {}).get("velocity", _vector3_to_dict(Vector3.ZERO)),
			target_frame.get("ball", {}).get("velocity", _vector3_to_dict(Vector3.ZERO)),
			weight
		),
		"topspin": lerpf(
			float(previous_frame.get("ball", {}).get("topspin", 0.0)),
			float(target_frame.get("ball", {}).get("topspin", 0.0)),
			weight
		)
	}

	return {
		"timestamp": lerpf(float(previous_frame.get("timestamp", 0.0)), float(target_frame.get("timestamp", 0.0)), weight),
		"phase": str(target_frame.get("phase", previous_frame.get("phase", ""))),
		"source": "interpolated_stub",
		"ball": interpolated_ball,
		"teams": _interpolate_teams(previous_frame.get("teams", []), target_frame.get("teams", []), weight),
		"focus": target_frame.get("focus", {}).duplicate(true),
		"stub_flags": [
			"interpolated_ball_path",
			"interpolated_player_path",
			"player_animation_assignment_stub"
		]
	}

static func _interpolate_teams(previous_teams: Array, target_teams: Array, weight: float) -> Array[Dictionary]:
	var team_count: int = max(previous_teams.size(), target_teams.size())
	var teams: Array[Dictionary] = []

	for i in range(team_count):
		var previous_team: Dictionary = previous_teams[i] if i < previous_teams.size() else {}
		var target_team: Dictionary = target_teams[i] if i < target_teams.size() else previous_team
		if previous_team.is_empty():
			teams.append(target_team.duplicate(true))
			continue
		if target_team.is_empty():
			teams.append(previous_team.duplicate(true))
			continue

		var interpolated_team: Dictionary = target_team.duplicate(true)
		var previous_players: Array = previous_team.get("players", [])
		var target_players: Array = target_team.get("players", [])
		var players: Array[Dictionary] = []
		var player_count: int = max(previous_players.size(), target_players.size())

		for player_index in range(player_count):
			var previous_player: Dictionary = previous_players[player_index] if player_index < previous_players.size() else {}
			var target_player: Dictionary = target_players[player_index] if player_index < target_players.size() else previous_player
			if previous_player.is_empty():
				players.append(target_player.duplicate(true))
				continue
			if target_player.is_empty():
				players.append(previous_player.duplicate(true))
				continue

			var player: Dictionary = target_player.duplicate(true)
			player["position"] = _lerp_vector3_dict(
				previous_player.get("position", _vector3_to_dict(Vector3.ZERO)),
				target_player.get("position", _vector3_to_dict(Vector3.ZERO)),
				weight
			)
			player["animation"] = _select_animation(previous_player.get("animation", {}), target_player.get("animation", {}), weight)
			players.append(player)

		interpolated_team["players"] = players
		teams.append(interpolated_team)

	return teams

static func _select_animation(previous_animation: Dictionary, target_animation: Dictionary, weight: float) -> Dictionary:
	if weight < 0.5 and not previous_animation.is_empty():
		return previous_animation.duplicate(true)
	if not target_animation.is_empty():
		return target_animation.duplicate(true)
	return previous_animation.duplicate(true)

static func _athlete_name(athlete: AthleteStats) -> String:
	if athlete == null:
		return "Unknown Athlete"
	return "%s %s" % [athlete.firstName, athlete.lastName]

static func _vector3_to_dict(value: Vector3) -> Dictionary:
	return {
		"x": value.x,
		"y": value.y,
		"z": value.z
	}

static func _lerp_vector3_dict(from: Dictionary, to: Dictionary, weight: float) -> Dictionary:
	return {
		"x": lerpf(float(from.get("x", 0.0)), float(to.get("x", 0.0)), weight),
		"y": lerpf(float(from.get("y", 0.0)), float(to.get("y", 0.0)), weight),
		"z": lerpf(float(from.get("z", 0.0)), float(to.get("z", 0.0)), weight)
	}
