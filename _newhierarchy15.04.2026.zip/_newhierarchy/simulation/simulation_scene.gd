extends Node2D

@export_enum("Basic", "Intermediate", "Verbose") var demo_log_verbosity: int = 1

@onready var generate_world_button: Button = $CanvasLayer/Control/VBoxContainer/Buttons/GenerateWorldButton
@onready var play_point_button: Button = $CanvasLayer/Control/VBoxContainer/Buttons/PlayPointButton
@onready var play_set_button: Button = $CanvasLayer/Control/VBoxContainer/Buttons/PlaySetButton
@onready var next_rally_step_button: Button = $CanvasLayer/Control/VBoxContainer/Buttons/NextRallyStepButton
@onready var replay_last_point_button: Button = $CanvasLayer/Control/VBoxContainer/Buttons/ReplayLastPointButton
@onready var next_replay_frame_button: Button = $CanvasLayer/Control/VBoxContainer/Buttons/NextReplayFrameButton
@onready var status_label: Label = $CanvasLayer/Control/VBoxContainer/StatusLabel
@onready var rally_step_label: Label = $CanvasLayer/Control/VBoxContainer/RallyStepLabel
@onready var replay_label: Label = $CanvasLayer/Control/VBoxContainer/ReplayLabel

var sim: MatchSimulation
var director: SimulationDirector
var workflow_log: SimulationEventLog
var simulation_world: SimulationWorldState
var active_replay: Dictionary = {}
var active_replay_frames: Array = []
var replay_frame_index: int = -1

func _ready() -> void:
	workflow_log = SimulationEventLog.new()
	workflow_log.configure(demo_log_verbosity)
	director = SimulationDirector.new(workflow_log)

	generate_world_button.pressed.connect(_on_generate_world_button_pressed)
	play_point_button.pressed.connect(_on_play_point_button_pressed)
	play_set_button.pressed.connect(_on_play_set_button_pressed)
	next_rally_step_button.pressed.connect(_on_next_rally_step_button_pressed)
	replay_last_point_button.pressed.connect(_on_replay_last_point_button_pressed)
	next_replay_frame_button.pressed.connect(_on_next_replay_frame_button_pressed)
	_set_match_buttons_enabled(false)
	_refresh_status_text("Ready to generate world")
	_refresh_rally_step_text("No rally steps yet")
	_refresh_replay_text("No replay loaded")

func _on_generate_world_button_pressed() -> void:
	simulation_world = SimulationWorldState.new()
	director.generate_game_world(simulation_world)

	var team_a := TeamData.new()
	team_a.teamName = "Alpha"
	team_a.Populate(PlayerChoiceState.new(), ["Cameron"], ["Borgas"])
	_prefix_generated_player_names(team_a)
	team_a.select_starting_lineup()

	var team_b := TeamData.new()
	team_b.teamName = "Bravo"
	team_b.Populate(PlayerChoiceState.new(), ["Tiglath-Pileser"], ["III"])
	_prefix_generated_player_names(team_b)
	team_b.select_starting_lineup()

	sim = MatchSimulation.new(team_a, team_b, -1, workflow_log)
	_set_match_buttons_enabled(true)
	_refresh_status_text("Game world generated")
	_refresh_rally_step_text("No rally steps yet")
	_clear_active_replay("No replay loaded")

func _on_play_point_button_pressed() -> void:
	if sim == null:
		_refresh_status_text("Generate world first")
		return
	_refresh_rally_step_text("Rally step output cleared")
	var result := sim.play_point()
	if result["type"] == "match_over":
		_refresh_status_text("Match complete")
		return
	_load_replay(result.get("replay", {}))

	var score_event: Dictionary = result["score_event"]
	var summary := "Point played"
	if score_event["type"] == "set_over":
		summary = "Set over: %s" % score_event["winner"].teamName
	elif score_event["type"] == "match_over":
		summary = "Match over: %s" % score_event["winner"].teamName

	_refresh_status_text(summary)

func _on_play_set_button_pressed() -> void:
	if sim == null:
		_refresh_status_text("Generate world first")
		return
	_refresh_rally_step_text("Rally step output cleared")
	var result := sim.play_set()
	if result["type"] == "match_over":
		_refresh_status_text("Match complete")
		return
	if not sim.rally_replays.is_empty():
		_load_replay(sim.rally_replays[sim.rally_replays.size() - 1].get("replay", {}))

	var ending_event: Dictionary = result["ending_event"]
	var summary := "Set %d completed (%d rallies)" % [result["set_number"], result["rallies_played"]]
	if ending_event["type"] == "match_over":
		summary = "Match over: %s" % ending_event["winner"].teamName
	elif ending_event["type"] == "set_over":
		summary = "Set %d over: %s" % [result["set_number"], ending_event["winner"].teamName]

	_refresh_status_text(summary)

func _on_next_rally_step_button_pressed() -> void:
	if sim == null:
		_refresh_status_text("Generate world first")
		_refresh_rally_step_text("No rally steps yet")
		return

	var result := sim.next_rally_step()
	_refresh_rally_step_text(result.get("message", ""))

	if result["type"] == "match_over":
		_refresh_status_text("Match complete")
		return

	if result.get("rally_committed", false):
		var point_result: Dictionary = result["point_result"]
		_load_replay(point_result.get("replay", {}))
		var score_event: Dictionary = point_result["score_event"]
		var summary := "Rally step complete"
		if score_event["type"] == "set_over":
			summary = "Set over: %s" % score_event["winner"].teamName
		elif score_event["type"] == "match_over":
			summary = "Match over: %s" % score_event["winner"].teamName
		else:
			summary = "Point played"
		_refresh_status_text(summary)
		return

	_refresh_status_text("Rally %d in progress" % sim.rally_number)

func _on_replay_last_point_button_pressed() -> void:
	if sim == null or sim.rally_replays.is_empty():
		_refresh_replay_text("No completed point replay available")
		return
	_load_replay(sim.rally_replays[sim.rally_replays.size() - 1].get("replay", {}))
	_show_next_replay_frame()

func _on_next_replay_frame_button_pressed() -> void:
	_show_next_replay_frame()

func _refresh_status_text(prefix: String) -> void:
	if sim == null:
		var world_state := "not generated"
		if simulation_world != null:
			world_state = "generated"
		status_label.text = "%s\nNo active match\nWorld: %s" % [prefix, world_state]
		return


	var sets_a: int = int(sim.score.sets_won[sim.team_a])
	var sets_b: int = int(sim.score.sets_won[sim.team_b])
	var points_a: int = int(sim.score.points[sim.team_a])
	var points_b: int = int(sim.score.points[sim.team_b])
	var serving_team_name: String = "N/A"
	var server_name: String = "N/A"


	if sim.serving_team != null:
		serving_team_name = sim.serving_team.teamName
		var server: AthleteStats = sim.get_current_server()
		if server != null:
			server_name = "%s %s" % [server.firstName, server.lastName]

	status_label.text = "%s\nSets %s %d - %s %d\nPoints %s %d - %s %d\nServing: %s\nServer: %s\nRallies: %d" % [
		prefix,
		sim.team_a.teamName, sets_a, sim.team_b.teamName, sets_b,
		sim.team_a.teamName, points_a, sim.team_b.teamName, points_b,
		serving_team_name, server_name,
		sim.rally_number
	]

func _set_match_buttons_enabled(enabled: bool) -> void:
	play_point_button.disabled = not enabled
	play_set_button.disabled = not enabled
	next_rally_step_button.disabled = not enabled
	replay_last_point_button.disabled = not enabled
	next_replay_frame_button.disabled = not enabled

func _refresh_rally_step_text(message: String) -> void:
	rally_step_label.text = "Rally Step Output:\n%s" % message

func _refresh_replay_text(message: String) -> void:
	replay_label.text = "Replay Output:\n%s" % message

func _clear_active_replay(message: String) -> void:
	active_replay = {}
	active_replay_frames = []
	replay_frame_index = -1
	_refresh_replay_text(message)

func _load_replay(replay: Dictionary) -> void:
	if replay.is_empty():
		_clear_active_replay("Replay missing")
		return

	active_replay = replay.duplicate(true)
	active_replay_frames = active_replay.get("frames", [])
	replay_frame_index = -1
	var summary: Dictionary = active_replay.get("summary", {})
	_refresh_replay_text(
		"Loaded replay for rally %s (%d frames, %d keyframes)"
		% [
			str(summary.get("rally_number", "?")),
			active_replay_frames.size(),
			int(summary.get("keyframe_count", 0))
		]
	)

func _show_next_replay_frame() -> void:
	if active_replay_frames.is_empty():
		_refresh_replay_text("No replay frames loaded")
		return

	replay_frame_index += 1
	if replay_frame_index >= active_replay_frames.size():
		replay_frame_index = 0

	var frame: Dictionary = active_replay_frames[replay_frame_index]
	_refresh_replay_text(_describe_replay_frame(frame))

func _describe_replay_frame(frame: Dictionary) -> String:
	var ball: Dictionary = frame.get("ball", {})
	var ball_position: Dictionary = ball.get("position", {})
	var focus: Dictionary = frame.get("focus", {})
	var lines: Array[String] = []
	lines.append(
		"Frame %d | t=%.2fs | phase=%s | action=%s | result=%s"
		% [
			replay_frame_index,
			float(frame.get("timestamp", 0.0)),
			str(frame.get("phase", "")),
			str(focus.get("action", "")),
			str(focus.get("result", ""))
		]
	)
	lines.append(
		"Ball pos=(%.2f, %.2f, %.2f)"
		% [
			float(ball_position.get("x", 0.0)),
			float(ball_position.get("y", 0.0)),
			float(ball_position.get("z", 0.0))
		]
	)

	var teams: Array = frame.get("teams", [])
	for team_data in teams:
		lines.append(_describe_replay_team(team_data))

	if frame.get("is_keyframe", false):
		lines.append("Keyframe")
	if not frame.get("stub_flags", []).is_empty():
		lines.append("Stub data: %s" % _join_variant_list(frame.get("stub_flags", [])))

	return "\n".join(lines)

func _describe_replay_team(team_data: Dictionary) -> String:
	var players: Array = team_data.get("players", [])
	if players.is_empty():
		return "%s: no player data" % str(team_data.get("team_name", "Team"))

	var snippets: Array[String] = []
	for i in range(min(players.size(), 2)):
		var player: Dictionary = players[i]
		var position: Dictionary = player.get("position", {})
		var animation: Dictionary = player.get("animation", {})
		snippets.append(
			"%s @ (%.1f, %.1f, %.1f) -> %s"
			% [
				str(player.get("player_name", "")),
				float(position.get("x", 0.0)),
				float(position.get("y", 0.0)),
				float(position.get("z", 0.0)),
				str(animation.get("name", ""))
			]
		)

	return "%s: %s" % [str(team_data.get("team_name", "Team")), " | ".join(snippets)]

func _join_variant_list(values: Array) -> String:
	var parts: Array[String] = []
	for value in values:
		parts.append(str(value))
	return ", ".join(parts)

func _prefix_generated_player_names(team: TeamData) -> void:
	for i in range(team.matchPlayers.size()):
		var athlete: AthleteStats = team.matchPlayers[i]
		athlete.firstName = "[%d] %s" % [i + 1, athlete.firstName]
